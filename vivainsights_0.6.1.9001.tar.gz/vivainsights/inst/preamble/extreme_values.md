
This section runs checks against the core collaboration metrics (Email, Meeting, Teams Call, and Teams Instant Message hours) to flag any extreme values. If a significant number of extreme high or low values is identified, the Analyst is recommended to investigate the cause before proceeding further with the analysis.         


 
 
     
 
