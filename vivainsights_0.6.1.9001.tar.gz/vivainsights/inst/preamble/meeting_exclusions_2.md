
If you believe that your meeting data requires further cleanup, please consider defining a new meeting exclusion rule under Settings in Viva Insights and re-running your queries. If you want to further investigate this issue, you can flag these meetings in your dataset using `subject_validate(data, return = "data")`. You can also generate a more detailed report using `subject_validate_report()`.  

---


