
This section provides a view of the licensed population **available in the query** over time. Note that the values seen on this plot could differ from the actual licensed population due to filters on Activeness, holiday weeks, and non-knowledge workers.  
     
 
