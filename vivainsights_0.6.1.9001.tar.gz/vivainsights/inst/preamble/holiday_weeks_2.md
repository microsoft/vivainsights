
You can easily remove holiday weeks from your dataset by using the function `identify_holidayweeks(return = "data_cleaned")`.  
​     

