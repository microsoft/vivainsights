
Abnormal Outlook settings (i.e. significant number of users defining very short or very long working days) may skew analysis results, making after-hours collaboration look particularly high or small.  


