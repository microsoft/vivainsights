## Overview

In this report, you will find a series of summary and analysis relating to key **capacity** metrics in Viva Insights, including length of week and time in after-hours collaboration.

For full metric definitions, please visit our [official documentation](https://docs.microsoft.com/en-us/workplace-analytics/use/metric-definitions).

---

