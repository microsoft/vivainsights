
The table below shows the organizational attributes available in this dataset. Use this table to understand the data's quality and completeness.  

* Be mindful of attributes that have many unique values, as this may limit data aggregation and filtering (For example, if a job function or code is too narrowly defined, it might not give you a useful view of the overall group).   
* Additionally, review missing values as some attributes may only be partially available for the population in this sample:  
