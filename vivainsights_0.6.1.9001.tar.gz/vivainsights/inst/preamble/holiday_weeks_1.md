
**Holiday weeks**: these refer to **weeks** in the data where the collaboration hours of the sample are unusually low. These are typically removed from analysis as they represent public holidays where the patterns of collaboration are not representative of the norm. Note that this applies to weeks, i.e. the data of the week is removed for all employees in the sample.  


 
 
     
 
