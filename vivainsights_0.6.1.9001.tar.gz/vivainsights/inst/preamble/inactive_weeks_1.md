
**Inactive weeks** are **person-weeks** in the data where the collaboration hours of the sample are unusually low. These are typically removed as they represent individual holidays where the patterns of collaboration are not representative of the norm. Note that this applies to *person-weeks*, i.e. the data is only removed for an individual for a given week if it is low for that employee.    


 
 
     
 
