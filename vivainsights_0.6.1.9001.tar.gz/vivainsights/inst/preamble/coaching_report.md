## Overview

In this report, you will find a series of summary and analysis relating to key **coaching** metrics in Viva Insights, specifically in relation to the time spent between managers and their direct reports. 

For full metric definitions, please visit our [official documentation](https://docs.microsoft.com/en-us/workplace-analytics/use/metric-definitions).

---
